<?php 
include("data.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Resultado de búsqueda</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba</title>
	<body style="background-color:beige;">
 <center>
<h3 class="text-center">Resultado de la busqueda :</h3>
<br>
<a href="index.html" style="color:waith"class="btn1 btn-success ">Retroceder</a>
</center>
<br><br>
<?php
		if(isset($_POST['buscar']))
		{
		include("data.php");	
		
		$cod = $_POST['cbx_idel'];
		$resultado = mysqli_query($conn,"SELECT * FROM listing1  WHERE ID= '$cod'");
	while($consultas = mysqli_fetch_assoc($resultado))
	  {
		echo 
		'
		<table class="table table-hover">
			<tr>
			  
			  <th scope="col">ID</th>
			  <th scope="col">Name</th>
			  <th scope="col">Telefono</th>
			  <th scope="col">Edad</th>

			</tr>
				
			<tr>
		      <td><b>'.$consultas['ID'].'</b></td>
			  <td><b>'.$consultas['Name'].'</b></td>
			  <td><b>'.$consultas['Telefono'].'</b></td>
			  <td><b>'.$consultas['Edad'].'</b></td>
			</tr>
	    ';
		}
	  }	

       echo '</table>';

?>
