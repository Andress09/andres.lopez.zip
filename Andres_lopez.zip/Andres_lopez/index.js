var app ={};
var miCallback = datos =>{
    console.log(datos);
    app.prueba=datos;
    var html =""
    html+="<h2>Prueba</h2"
    app.prueba.map(prueba =>{
        html+="<img src='"+prueba.img+"'></img>";
        for(let propiedad of Object.keys(prueba)){
            html+="<li>"+propiedad+":"+prueba[propiedad]+"</li>";

        }
        html+="<hr/>"
    })
    document.getElementById("results").innerHTML = html;
}