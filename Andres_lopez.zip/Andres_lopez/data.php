
<?php
    $conn=mysqli_connect('localhost','root','','listing');
    if($conn){

    }else{
        echo "Error de Conexion" .mysqli_error($conn);
    }
?>
